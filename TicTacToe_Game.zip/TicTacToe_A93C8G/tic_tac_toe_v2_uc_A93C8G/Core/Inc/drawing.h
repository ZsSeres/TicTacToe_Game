/*
 * drawing.h
 *
 *  Created on: 2021. máj. 10.
 *      Author: Zsombi
 */

#ifndef INC_DRAWING_H_
#define INC_DRAWING_H_
#include <stdio.h>
#include <game_matrix.h>
//Egy 128x64 képernyő minden eggyes bitjére meg kell mondanom, hogy 0-s vagy 1-s

//Segédfüggvények a képernyő kezeléséhez
// Kis Matek: 128x64=8192db pontról kell megmondanom, hogy 0-s vagy 1-s.
//uint8_t a legkisebb egységem annak a segítségével megtudom, mondani 8 db pixelnek az értékét
//Így összesen egy uint_8t[1024]-s tömbbel letudom írni az egész képernyőt
//Az indexelés az alábbi pl lcd_buffer[0] az 0,0-7,0-ig megmondja a pixelek értékét
//Tehát a felosztás:egy sor 0-15-ig utánna a következő sor 16-31-ig balról jobbra, egészen jobb felső sarkoig amely
//az 1023-as számú tömb.

//Draw Pixel:
//Megfelelő koordinátákba lévő pixel értékét egybe állítja
//Itt a nem matekozós 128x64-s koordináta rendszert kell nézni, ahol bal alsó sarokba található a 0x0
void Draw_Pixel(uint8_t* lcd_buffer, uint16_t size,int xpos, int ypos);


//Törli a képernyőt
void Clear_Screen(uint8_t* lcd_buffer, uint16_t size);

//Függőleges vonalat rajzol:
//x és y pos a vonal bal alsó sarkát jelzi
void Draw_Vertical_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length);

//Vízszintes vonalat rajzol:
void Draw_Horizontal_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length);

void Draw_Thick_Vertical_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length,int width);

void Draw_Thick_Horizontal_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length,int width);

//"Pálya kirajzolása"
void Draw_Frame(uint8_t* lcd_buffer,uint16_t size);

//Rajzol egy téglalapot:
//xpos, ypos a téglalap bal alsó sarkának koordniátái
void Draw_Rect(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width, int length);


//Ferde 0.5 meredekségű vonalat rajzol
//xpos, ypos a vonal bal alsó sarkát adja meg
void Draw_Line_Cross(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width);
//-0.5 meredekségű egyenes
void Draw_Line_Cross2(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width);

//négyzet rajzolása
void Draw_Player1_Symbol(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos);

//"X" rajzolása
void Draw_Player2_Symbol(uint8_t* lcd_buffer,uint16_t size,int xpos, int ypos);

//A szimbólumokat "O" és "X" helyett "|" és "-"
void Draw_Symbols(uint8_t* lcd_buffer,uint16_t size,Game_Matrix game_matrix);


#endif /* INC_DRAWING_H_*/


