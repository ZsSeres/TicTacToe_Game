#include <game_matrix.h>
//Magát a logikát megvalósító függvények

const int cell_type_clr=0;
const int cell_type_O=1;
const int cell_type_X= 2;


//Játékosok:
const int Player_O =1;
const int Player_X =2;

//Törli a Mátrix egészét:
void Clear_Matrix(Game_Matrix* matrix)
{
	for(int i=0;i<3;i++)
	{
		matrix->row1[i]=cell_type_clr;
		matrix->row2[i]=cell_type_clr;
		matrix->row3[i]=cell_type_clr;
	}
}

//Megmondja az adott celláról, hogy szabad-e:
//0-s igen
//egyéb nem
int Cell_isFree(Cell_Pos* cell_pos,Game_Matrix* matrix)
{
	int sol=0;
	if(cell_pos->row==0)
	{sol=matrix->row1[cell_pos->column];}
	if(cell_pos->row==1)
	{sol=matrix->row2[cell_pos->column];}
	if(cell_pos->row==2)
	{sol=matrix->row3[cell_pos->column];}

	return sol;
}

//Az alapján, hogy melyik játékos és melyik cell_pos beír a Mátrix megfelelő helyére
//Természetesen csak a szabad helyre
void Set_Cell(Cell_Pos* cell_pos,int current_player,Game_Matrix* matrix)
{
	int cell=0;
	if(current_player==Player_O){cell=cell_type_O;}
	if(current_player==Player_X){cell=cell_type_X;}

	if(cell_pos->row==0){matrix->row1[cell_pos->column]=cell;}
	if(cell_pos->row==1){matrix->row2[cell_pos->column]=cell;}
	if(cell_pos->row==2){matrix->row3[cell_pos->column]=cell;}
	//Vmi jelzés, hogy hibás???
}

//Megmondja, hogy az adott karakterből van-e fullos sor
//4:első sor fullo
//5:második sor fullos
//6:3. sor fullos

int isanyrowfull(int current_player,Game_Matrix* matrix)
{
	int sol=0;
	int counter=0;
	//egy tipikus sor checkolása:
	//row1:
	for(int i=0;i<3;i++)
	{

		if(matrix->row1[i]==current_player)
			counter++;
		if(counter==3)
		{
			sol=1;
			return sol;
		}
	}
	counter=0;
	//row2:
	for(int i=0;i<3;i++)
		{

			if(matrix->row2[i]==current_player)
				counter++;
			if(counter==3)
			{
				sol=1;
				return sol;
			}
		}
	counter=0;
	//row3:
	for(int i=0;i<3;i++)
			{

				if(matrix->row3[i]==current_player)
					counter++;
				if(counter==3)
				{
					sol=1;
					return sol;
				}
			}

	return sol;
}

//Megmondja a Mátrixnak van-e olyan sora, ami fullos, az adott karakterrel
int isanycolumnfull(int current_player,Game_Matrix* matrix)
{
	int sol=0;

	for(int i=0;i<3;i++)
	{
	//Egy oszlop:
		if((current_player==matrix->row1[i]) && (matrix->row1[i]==matrix->row2[i]) && (matrix->row2[i]==matrix->row3[i]))
		{
			sol=1;
			return sol;
		}
	}
	return sol;
}

//Megmondja hogy keresztbe van-e fullos sor az adott karakterből.
int isanycrossfull(int current_player,Game_Matrix* matrix)
{
	int sol=0;

	//Egyik átló:
	if((current_player==matrix->row1[0]) && (matrix->row1[0]==matrix->row2[1]) && (matrix->row2[1]==matrix->row3[2]))
	{
		sol=1;
		return sol;
	}
	//Másik átló:
	if((current_player==matrix->row1[2]) && (matrix->row1[2]==matrix->row2[1]) && (matrix->row2[1]==matrix->row3[0]))
		{
			sol=1;
			return sol;
		}
	return sol;

}
//A mátrix és az alapján, hogy kinek a köre van éppen, megmondja, hogy nyert-e valaki és ha igen, akkor ki
//0-nincs még vége a játéknak
//
int isGame_Over(int currentplayer,Game_Matrix* matrix)
{
	int sol=0;
	if(isanyrowfull(currentplayer,matrix)==1 || isanycolumnfull(currentplayer,matrix)==1 || isanycrossfull(currentplayer,matrix)==1)
		sol=1;
	if(sol==1)
		return currentplayer;
	else
		return 0;

}






