﻿
namespace tictactoeclientapp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.gb_Com = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pb_Com = new System.Windows.Forms.ProgressBar();
            this.b_Close = new System.Windows.Forms.Button();
            this.b_Open = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_COM_PORT = new System.Windows.Forms.ComboBox();
            this.gb_Periphery = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.l_isgameover = new System.Windows.Forms.Label();
            this.l_step = new System.Windows.Forms.Label();
            this.l_player = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.reset = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.key8 = new System.Windows.Forms.Button();
            this.key7 = new System.Windows.Forms.Button();
            this.key6 = new System.Windows.Forms.Button();
            this.key5 = new System.Windows.Forms.Button();
            this.key4 = new System.Windows.Forms.Button();
            this.key3 = new System.Windows.Forms.Button();
            this.key2 = new System.Windows.Forms.Button();
            this.key1 = new System.Windows.Forms.Button();
            this.key0 = new System.Windows.Forms.Button();
            this.gb_Com.SuspendLayout();
            this.gb_Periphery.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            // 
            // gb_Com
            // 
            this.gb_Com.Controls.Add(this.label2);
            this.gb_Com.Controls.Add(this.pb_Com);
            this.gb_Com.Controls.Add(this.b_Close);
            this.gb_Com.Controls.Add(this.b_Open);
            this.gb_Com.Controls.Add(this.label1);
            this.gb_Com.Controls.Add(this.cb_COM_PORT);
            this.gb_Com.Location = new System.Drawing.Point(74, 436);
            this.gb_Com.Name = "gb_Com";
            this.gb_Com.Size = new System.Drawing.Size(517, 100);
            this.gb_Com.TabIndex = 0;
            this.gb_Com.TabStop = false;
            this.gb_Com.Text = "ComPortControl";
            this.gb_Com.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Progress";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pb_Com
            // 
            this.pb_Com.Location = new System.Drawing.Point(209, 58);
            this.pb_Com.Name = "pb_Com";
            this.pb_Com.Size = new System.Drawing.Size(100, 23);
            this.pb_Com.TabIndex = 4;
            // 
            // b_Close
            // 
            this.b_Close.Location = new System.Drawing.Point(436, 58);
            this.b_Close.Name = "b_Close";
            this.b_Close.Size = new System.Drawing.Size(75, 23);
            this.b_Close.TabIndex = 3;
            this.b_Close.Text = "Close";
            this.b_Close.UseVisualStyleBackColor = true;
            this.b_Close.Click += new System.EventHandler(this.b_Close_Click);
            // 
            // b_Open
            // 
            this.b_Open.Location = new System.Drawing.Point(436, 19);
            this.b_Open.Name = "b_Open";
            this.b_Open.Size = new System.Drawing.Size(75, 23);
            this.b_Open.TabIndex = 2;
            this.b_Open.Text = "Open";
            this.b_Open.UseVisualStyleBackColor = true;
            this.b_Open.Click += new System.EventHandler(this.b_Open_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "COM PORT";
            // 
            // cb_COM_PORT
            // 
            this.cb_COM_PORT.FormattingEnabled = true;
            this.cb_COM_PORT.Location = new System.Drawing.Point(199, 21);
            this.cb_COM_PORT.Name = "cb_COM_PORT";
            this.cb_COM_PORT.Size = new System.Drawing.Size(121, 21);
            this.cb_COM_PORT.TabIndex = 0;
            // 
            // gb_Periphery
            // 
            this.gb_Periphery.Controls.Add(this.groupBox1);
            this.gb_Periphery.Controls.Add(this.reset);
            this.gb_Periphery.Controls.Add(this.groupBox2);
            this.gb_Periphery.Location = new System.Drawing.Point(73, 286);
            this.gb_Periphery.Name = "gb_Periphery";
            this.gb_Periphery.Size = new System.Drawing.Size(533, 144);
            this.gb_Periphery.TabIndex = 1;
            this.gb_Periphery.TabStop = false;
            this.gb_Periphery.Text = "SimulatedPeriphery";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.l_isgameover);
            this.groupBox1.Controls.Add(this.l_step);
            this.groupBox1.Controls.Add(this.l_player);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(31, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info";
            // 
            // l_isgameover
            // 
            this.l_isgameover.AutoSize = true;
            this.l_isgameover.Location = new System.Drawing.Point(111, 76);
            this.l_isgameover.Name = "l_isgameover";
            this.l_isgameover.Size = new System.Drawing.Size(0, 13);
            this.l_isgameover.TabIndex = 5;
            // 
            // l_step
            // 
            this.l_step.AutoSize = true;
            this.l_step.Location = new System.Drawing.Point(111, 48);
            this.l_step.Name = "l_step";
            this.l_step.Size = new System.Drawing.Size(0, 13);
            this.l_step.TabIndex = 4;
            // 
            // l_player
            // 
            this.l_player.AutoSize = true;
            this.l_player.Location = new System.Drawing.Point(111, 20);
            this.l_player.Name = "l_player";
            this.l_player.Size = new System.Drawing.Size(0, 13);
            this.l_player.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(6, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Game State:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(48, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Step:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(37, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Player:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(449, 73);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(75, 23);
            this.reset.TabIndex = 3;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.key8);
            this.groupBox2.Controls.Add(this.key7);
            this.groupBox2.Controls.Add(this.key6);
            this.groupBox2.Controls.Add(this.key5);
            this.groupBox2.Controls.Add(this.key4);
            this.groupBox2.Controls.Add(this.key3);
            this.groupBox2.Controls.Add(this.key2);
            this.groupBox2.Controls.Add(this.key1);
            this.groupBox2.Controls.Add(this.key0);
            this.groupBox2.Location = new System.Drawing.Point(275, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(168, 111);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Buttons";
            // 
            // key8
            // 
            this.key8.Location = new System.Drawing.Point(112, 79);
            this.key8.Name = "key8";
            this.key8.Size = new System.Drawing.Size(21, 21);
            this.key8.TabIndex = 8;
            this.key8.Text = "8";
            this.key8.UseVisualStyleBackColor = true;
            this.key8.Click += new System.EventHandler(this.key8_Click);
            // 
            // key7
            // 
            this.key7.Location = new System.Drawing.Point(76, 79);
            this.key7.Name = "key7";
            this.key7.Size = new System.Drawing.Size(21, 21);
            this.key7.TabIndex = 7;
            this.key7.Text = "7";
            this.key7.UseVisualStyleBackColor = true;
            this.key7.Click += new System.EventHandler(this.key7_Click);
            // 
            // key6
            // 
            this.key6.Location = new System.Drawing.Point(36, 79);
            this.key6.Name = "key6";
            this.key6.Size = new System.Drawing.Size(21, 21);
            this.key6.TabIndex = 3;
            this.key6.Text = "6";
            this.key6.UseVisualStyleBackColor = true;
            this.key6.Click += new System.EventHandler(this.key6_Click);
            // 
            // key5
            // 
            this.key5.Location = new System.Drawing.Point(112, 46);
            this.key5.Name = "key5";
            this.key5.Size = new System.Drawing.Size(21, 21);
            this.key5.TabIndex = 6;
            this.key5.Text = "5";
            this.key5.UseVisualStyleBackColor = true;
            this.key5.Click += new System.EventHandler(this.key5_Click);
            // 
            // key4
            // 
            this.key4.Location = new System.Drawing.Point(76, 46);
            this.key4.Name = "key4";
            this.key4.Size = new System.Drawing.Size(21, 21);
            this.key4.TabIndex = 5;
            this.key4.Text = "4";
            this.key4.UseVisualStyleBackColor = true;
            this.key4.Click += new System.EventHandler(this.key4_Click);
            // 
            // key3
            // 
            this.key3.Location = new System.Drawing.Point(36, 46);
            this.key3.Name = "key3";
            this.key3.Size = new System.Drawing.Size(21, 21);
            this.key3.TabIndex = 4;
            this.key3.Text = "3";
            this.key3.UseVisualStyleBackColor = true;
            this.key3.Click += new System.EventHandler(this.button3_Click);
            // 
            // key2
            // 
            this.key2.Location = new System.Drawing.Point(112, 19);
            this.key2.Name = "key2";
            this.key2.Size = new System.Drawing.Size(21, 21);
            this.key2.TabIndex = 3;
            this.key2.Text = "2";
            this.key2.UseVisualStyleBackColor = true;
            this.key2.Click += new System.EventHandler(this.key2_Click);
            // 
            // key1
            // 
            this.key1.Location = new System.Drawing.Point(76, 19);
            this.key1.Name = "key1";
            this.key1.Size = new System.Drawing.Size(21, 21);
            this.key1.TabIndex = 2;
            this.key1.Text = "1";
            this.key1.UseVisualStyleBackColor = true;
            this.key1.Click += new System.EventHandler(this.key1_Click);
            // 
            // key0
            // 
            this.key0.Location = new System.Drawing.Point(36, 19);
            this.key0.Name = "key0";
            this.key0.Size = new System.Drawing.Size(21, 21);
            this.key0.TabIndex = 1;
            this.key0.Text = "0";
            this.key0.UseVisualStyleBackColor = true;
            this.key0.Click += new System.EventHandler(this.key0_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 562);
            this.Controls.Add(this.gb_Periphery);
            this.Controls.Add(this.gb_Com);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.gb_Com.ResumeLayout(false);
            this.gb_Com.PerformLayout();
            this.gb_Periphery.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox gb_Com;
        private System.Windows.Forms.Button b_Close;
        private System.Windows.Forms.Button b_Open;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_COM_PORT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar pb_Com;
        private System.Windows.Forms.GroupBox gb_Periphery;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button key8;
        private System.Windows.Forms.Button key7;
        private System.Windows.Forms.Button key6;
        private System.Windows.Forms.Button key5;
        private System.Windows.Forms.Button key4;
        private System.Windows.Forms.Button key3;
        private System.Windows.Forms.Button key2;
        private System.Windows.Forms.Button key1;
        private System.Windows.Forms.Button key0;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label l_isgameover;
        private System.Windows.Forms.Label l_step;
        private System.Windows.Forms.Label l_player;
    }
}

