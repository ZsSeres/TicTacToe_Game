﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace tictactoeclientapp
{
    public partial class Form1 : Form
    {

        //
        object global_sender;
        SerialDataReceivedEventArgs global_e;




        string pressedkey;
        string DataIn = "";
        int index = 0;
        byte player = 16;
        byte step = 16;
        byte isGameOver = 16;
        string receivedData;

        bool isClosing = false;
        
        int received_num = 0;

        int screen_xoffs;

        Screen thescreen = new Screen(162, 250); //A képernyő bal alsó sarka a 162,174 pocízióban lesz

        byte[] received = new byte[1027];

        const int lcd_buffer_size = 1024;

        //Demo byte tömb, hogy jó-e? a decode
        byte[] lcd_buffer = new byte[lcd_buffer_size];


        public void FillDemoreceived()
        {
            for (int i = 0; i < lcd_buffer_size; i++)
            {
                lcd_buffer[i] = 255;
            }
        }



        public Form1()
        {
            InitializeComponent();
        }

        private void Send_Data(string key)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Write(key);
            }
            else
                MessageBox.Show("Failed to Send");
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MinimumSize = new Size(this.Width, this.Height);
            this.MaximumSize = new Size(this.Width, this.Height);


            string[] ports = SerialPort.GetPortNames();
            cb_COM_PORT.Items.AddRange(ports);
            gb_Periphery.SendToBack();

            //Képernyő törlése
            screen_xoffs = (this.Width-(thescreen.Width*thescreen.Scaler))/2;
            thescreen = new Screen(screen_xoffs, 280);
            thescreen.CleanScreen();
            //FillDemoreceived();
        }
        private void setGameStatus()
        {
            player = (byte)received[1024];
            step = (byte)received[1025];
            isGameOver = (byte)received[1026];

        }

        private void fillLcdBuffer()
        {
            for (int i = 0; i < lcd_buffer_size; i++)
            {
                lcd_buffer[i] = received[i];
            }
        }
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            
            serialPort1.Read(received,received_num,1);
            received_num++;
            if (received_num != 1027)//amíg nem jött meg az összes adat, addig hívjuk amíg meg nem jön
            { serialPort1_DataReceived(sender, e); }
            else// ha megjött az összes adat mi tévők legyünk?
            {
                setGameStatus();//player, step, stb beállítása
                fillLcdBuffer();
                thescreen.Decode(lcd_buffer);
                received_num = 0;// ne felejstük 0-ni
            }

            
            Invalidate();
        }
        private void b_Open_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = cb_COM_PORT.Text;
                serialPort1.Open();
                serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
                pb_Com.Value = 100;

                Send_Data("9");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Failed to Open Port", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void b_Close_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                Send_Data("@");
                serialPort1.Close();
                pb_Com.Value = 0;
                thescreen.CleanScreen();
                player = 16;
                step = 16;
                isGameOver = 16;
                Invalidate();
            }
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Key is pressed");
            if (e.KeyCode == Keys.A)
            {
                //Send_Data("1");

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Send_Data("3");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Send_Data("9");//ez a reset
        }

        private void key0_Click(object sender, EventArgs e)
        {
            Send_Data("0");
            //MessageBox.Show("Data Sent");
            Invalidate();
        }

        private void key1_Click(object sender, EventArgs e)
        {
            Send_Data("1");
        }

        private void key2_Click(object sender, EventArgs e)
        {
            Send_Data("2");
        }

        private void key4_Click(object sender, EventArgs e)
        {
            Send_Data("4");
        }

        private void key5_Click(object sender, EventArgs e)
        {
            Send_Data("5");
        }

        private void key6_Click(object sender, EventArgs e)
        {
            Send_Data("6");
        }

        private void key7_Click(object sender, EventArgs e)
        {
            Send_Data("7");
        }

        private void key8_Click(object sender, EventArgs e)
        {
            Send_Data("8");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        
        //Maga a rajzoló függvény:
        protected override void OnPaint(PaintEventArgs e)
        {
            //Rajzolgatáshoz:
            SolidBrush s = new SolidBrush(Color.Black);
            FontFamily ff = new FontFamily("Microsoft Sans Serif");
            System.Drawing.Font font = new System.Drawing.Font(ff, 10);

            //Infok kirajzolása:
            /*e.Graphics.DrawString(player.ToString(), font, s, 99, 20);
            e.Graphics.DrawString(isGameOver.ToString(), font, s, 99, 50);
            e.Graphics.DrawString(step.ToString(), font, s, 99, 77);*/
            if (player != 16 && isGameOver != 16 && step != 16)
            {
                l_player.Text = player.ToString();
                l_step.Text = step.ToString();
                l_isgameover.Text = isGameOver.ToString();
            }
            else
            {
                l_player.Text = "";
                l_step.Text = "";
                l_isgameover.Text = "";
            }
            //Képernyő kirajzolása:
            thescreen.DrawScreen(e.Graphics);


        }

        private void b_Draw_Click(object sender, EventArgs e)
        {
            byte dummy = 255;
            //thescreen.Decode(received_demo);
            thescreen._set8bit(dummy, 8, 63);
            Invalidate();
        }
    }
}
