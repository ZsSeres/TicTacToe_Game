﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tictactoeclientapp
{

    //ez osztály szimulálja a 128x64-s LCD kijelzőt 4x-szeres "nagyításban"
    class Screen
    {
        private bool[,] screen; //2D-s tömb mely a pixelek státuszát tárolja

        //A képernyő méretei
        private const int width = 128;
        private const int length = 64;
        private const int scaler = 4;

        public int Width
        {
            get => width;
        }

        public int Lenght
        {
            get => length;
        }

        public int Scaler
        {
            get => scaler;
        }

        //A képernyő bal alsó sarkának koordinátái
        private int xoffs = 0;
        private int yoffs = 0;

        //Pixel kirajzolásához brushok
        System.Drawing.SolidBrush BlackPixel = new System.Drawing.SolidBrush(System.Drawing.Color.Gray);
        System.Drawing.SolidBrush YellowPixel = new System.Drawing.SolidBrush(System.Drawing.Color.Yellow);


        public Screen()
        {
            screen = new bool[width, length];//létrejön maga a képernyő        
        }

        public Screen(int xoff, int yoff)
        {
            screen = new bool[width, length];
            xoffs = xoff;
            yoffs = yoff;
        }


        //1x8-as téglalap bitjeit beállítja
        public void _set8bit(byte input, int xindex, int yindex)
        {
            int input_int = (int)input;
            const int BITNUM = 8;
            int bitnum = 8;
            int isone = 0;
            for (int i = 0; i < BITNUM; i++)
            {
                // if ((input_int / (Math.Pow(2,bitnum-1))) != 0)
                if ((input_int-(input_int % (Math.Pow(2, bitnum - 1))))/(Math.Pow(2, bitnum - 1)) == 1)
                {
                    isone = 1;
                    screen[xindex + (bitnum - 1), yindex] = true;
                }
                else
                {
                    screen[xindex + (bitnum - 1), yindex] = false;
                    isone = 0;
                }
                input_int= (int)(input_int - (isone * (Math.Pow(2,bitnum-1))));
                bitnum--;
            }
        }
        
        //Ennek a függvények a feladata, hogy a beérkező byte tömbből kitöltse a 2D screen tömböt
        public void Decode(byte[] ReceivedData)
        {
            int yindex=0;
            int xindex=0;

            for(int i=0;i<1024;i++)
            {
                yindex = i / 16;
                xindex = (i % 16)*8;
                _set8bit(ReceivedData[i], xindex, yindex);
            }
        }

        //Kirajzolja a képernyőt. pixel[x][y]==true->rajzol fekete pixelt false esetén fehéret.
        public void DrawScreen(Graphics g)
        {
            
            
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < length; j++)
                {
                    int xpos = i*scaler + xoffs;
                    int ypos = (j-length)*scaler + yoffs;
                    if (screen[i, length-j-1] == true)
                    {
                        g.FillRectangle(YellowPixel, xpos, ypos,scaler,scaler);
                    }
                    else
                        g.FillRectangle(BlackPixel, xpos, ypos, scaler, scaler);

                }
            }
        }

        //Törli a képernyőt
        //Full fehér
        public void CleanScreen()
        {
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < length; j++)
                {
                    screen[i,j] = false;
                }
            }
        }

    }
}
