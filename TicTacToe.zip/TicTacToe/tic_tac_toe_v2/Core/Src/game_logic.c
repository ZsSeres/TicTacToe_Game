/*
 * game_logic.c
 *
 *  Created on: 2021. máj. 10.
 *      Author: Zsombi
 */


#include <game_logic.h>

extern const int cell_type_clr;
extern const int cell_type_O;
extern const int cell_type_X;


//Játékosok:
extern const int Player_O;
extern const int Player_X;

const int def_starting_player=1;

//Kör végén játékos váltás
void Player_Change(int* currentplayer)
{
	if(*currentplayer==Player_O)
	{
		*currentplayer=Player_X;
	}
	else
		*currentplayer=Player_O;
}

//Alaphelyzetbe állítja a game_statust
void Game_Status_Init(Game_Status* game_status){

	Clear_Matrix(&game_status->game_matrix);
	game_status->current_player=def_starting_player;
	game_status->step=0;
	game_status->isGameOver=0;
}



void Game_Init(Game_Status* game_status)
{
	Game_Status_Init(game_status);

}
//0-8-ig egészből csinál egy pozíció típusú változót
void inttoPos(uint8_t pressedkey,Cell_Pos* cell_pos)
{
	if(pressedkey<=0x32 && pressedkey>=0x30) cell_pos->row=0;
	if(pressedkey<=0x35 && pressedkey>=0x33) cell_pos->row=1;
	if(pressedkey<=0x38 && pressedkey>=0x36) cell_pos->row=2;


	if(pressedkey%3==0) cell_pos->column=0;
	if(pressedkey%3==1) cell_pos->column=1;
	if(pressedkey%3==2) cell_pos->column=2;

}

//Egy iterációja a játéknak
//UART-ról megkapjuk, hogy melyik "gombot" nyomták meg
//Tegyük fel, hogy a pressedkeybe, most normális értéke van 0-8-ig

/*void Game_Iteration(Game_Status* game_status,int pressedkey)
{
	//Elején van a játékos váltás
	Player_Change(&game_status->current_player);

	//Átalakítja a gomb nyomást pozícióvá
	Cell_Pos cell_pos=inttoPos(pressedkey);

	//Gombnyomás alapján állítja a Mátrixot
	Set_Cell(&cell_pos,&game_status->current_player,&game_status->game_matrix);

	//Növeljük a lépések számát
	game_status->step=(game_status->step)+1;

	//Checkolja, hogy véget ért-e játék
	if(isGame_Over(game_status->current_player,&game_status->game_matrix)!=0 || game_status->step==9)//Akkor is véget ér a játék ha elértük a 9 lépést
	{
		game_status->isGameOver=1;//jelezzük, hogy véget ért a Game
	}




}*/
//Ha az adott szám asci kódolásban 0 és 8 között van akkor 1-sel tér vissza
uint8_t iskeyValid(uint8_t key)
{
	if((key>=0x30)&&(key<=0x38))
	{
		return 1;
	}
	else
		return 0;
}

