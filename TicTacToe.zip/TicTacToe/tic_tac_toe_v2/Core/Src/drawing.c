/*
 * drawing.c
 *
 *  Created on: 2021. máj. 10.
 *      Author: Zsombi
 */

#include "drawing.h"

#define LCD_BUFF_SIZE 1024;

//A képernyő pixeljeit reprezentáló tömb
uint8_t Lcd_Buffer[1024];

//A képernyő adatai:
const uint8_t lcd_width=128;
const uint8_t lcd_height=64;


//0=<x<=127
//	0<=y<=63
void Draw_Pixel(uint8_t* lcd_buffer, uint16_t size,int xpos, int ypos)
{
	int row=ypos*16;
	int column=xpos/8;

	int column_index=xpos%8; //Megmondja tömmbön belül, hogy hányadik bitet piszkáljam
	//pl: column_index=6:
	//akkor 0000 0000->0100 0000

	int index=row+column;//Megmondja, hogy az 1024-s tömb melyik elemét piszkáljam


	if(column_index==0){ lcd_buffer[index]|=0b00000001;}
	if(column_index==1){ lcd_buffer[index]|=0b00000010;}
	if(column_index==2){ lcd_buffer[index]|=0b00000100;}
	if(column_index==3){ lcd_buffer[index]|=0b00001000;}
	if(column_index==4){ lcd_buffer[index]|=0b00010000;}
	if(column_index==5){ lcd_buffer[index]|=0b00100000;}
	if(column_index==6){ lcd_buffer[index]|=0b01000000;}
	if(column_index==7){ lcd_buffer[index]|=0b10000000;}
}

void Clear_Screen(uint8_t* lcd_buffer, uint16_t size)
{
	for(int i=0;i<size;i++)
		lcd_buffer[i]=0x00;
}
// 0<=xpos<=127
// 0<=ypos<=63
//1 széles függőleges vonal
void Draw_Vertical_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length)
{
	for(int i=0;i<length;i++)
	{
		Draw_Pixel(lcd_buffer,size,xpos,ypos+i);
	}


}

//1 széles, vízszintes vonal
void Draw_Horizontal_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length)
{
	for(int i=0;i<length;i++)
	{
		Draw_Pixel(lcd_buffer,size,xpos+i,ypos);
	}
}
//width széles függőleges vonal
void Draw_Thick_Vertical_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length,int width)
{
	for(int i=0;i<width;i++)
	{
		Draw_Vertical_Line(lcd_buffer,size,xpos+i,ypos,length);
	}
}

//width széles vízszintes vonal
void Draw_Thick_Horizontal_Line(uint8_t* lcd_buffer, uint16_t size,int xpos,int ypos,int length,int width)
{
	for(int i=0;i<width;i++)
		{
			Draw_Horizontal_Line(lcd_buffer,size,xpos,ypos+i,length);
		}
}

//Ezzel a megoldással megmarad a 128x64-s felbontás
//Úgy kéne felosztanom a pályát, hogy ugyanakkora téglalapokat kapjak, a vonal vastagságokkal, tudok játszani.
//Ahhoz, hogy téglalapokon belül megmaradjon a 2:1-s arány függőleges vonal vastagság 10, vízszintes 5
void Draw_Frame(uint8_t* lcd_buffer, uint16_t size)
{
	//2db függőleges:
	 Draw_Thick_Vertical_Line(lcd_buffer,size,36,0,64,10);//A képernyő teljes magasságába húz kettő 10 vastag függőleges vonalat;
	 Draw_Thick_Vertical_Line(lcd_buffer,size,82,0,64,10);

	 //2db vízszintes vonal:
	 Draw_Thick_Horizontal_Line(lcd_buffer,size,0,18,128,5);//A képernyő teljes széltében húz kettő 5 vastag vízszintes vonalat
	 Draw_Thick_Horizontal_Line(lcd_buffer,size,0,41,128,5);
}


void Draw_Rect(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width, int length)
{
	Draw_Vertical_Line(lcd_buffer,size,xpos,ypos,length);
	Draw_Vertical_Line(lcd_buffer,size,xpos+width,ypos,length);

	Draw_Horizontal_Line(lcd_buffer,size,xpos,ypos,width);
	Draw_Horizontal_Line(lcd_buffer,size,xpos,ypos+length,width+1);
}

//Bal alsó sarokból, jobb felsőbe tartó 0.5 meredekségű egyenes
void Draw_Line_Cross(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width)
{
	int ynovelo=0;
	for(int i=0;i<width;i++)
	{
		ynovelo=i%2;//Így oldom meg, hogy 0.5 meredekségű egyenest kapjak
		Draw_Pixel(lcd_buffer,size,xpos+i,ypos);
		ypos=ypos+ynovelo;
	}
}
//bal felső sarokból, jobb alsóba tartó -0.5 meredekségű egyenes
void Draw_Line_Cross2(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos,int width)
{
		int ycsokkento=0;
		for(int i=0;i<width;i++)
		{
			ycsokkento=i%2;//Így oldom meg, hogy -0.5 meredekségű egyenest kapjak
			Draw_Pixel(lcd_buffer,size,xpos+i,ypos);
			ypos=ypos-ycsokkento;
		}
}

//A player1 szimbóluma legyen egy 14x7-s téglalap, az alábbi fv ezt rajzolja le:
void Draw_Player1_Symbol(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos)
{
	Draw_Rect(lcd_buffer,size,xpos,ypos,14,7);
}



//A player2 szimbóluma egy kereszt amelynek vonalai 0.5 meredekségűek és vízszintes kiterjedésük 14
void Draw_Player2_Symbol(uint8_t* lcd_buffer,uint16_t size,int xpos,int ypos)
{
	Draw_Line_Cross(lcd_buffer,size,xpos,ypos,14);
	Draw_Line_Cross2(lcd_buffer,size,xpos,ypos+6,14);
}
//Itt a lényeg a játék állását ki kell rajolni
void Draw_Symbols(uint8_t* lcd_buffer,uint16_t size,Game_Matrix game_matrix)
{
	//Az offsetek azért kellenek, hogy ne 36x18-as téglalapok bal alsó sarkába, hanem nagyjából a közepükre jöjjenek ki a szimbólumok.
	int xoffs=11;
	int yoffs=5;
	for(int i=2;i>-1;i--)
	{
		//Alsó sor:
		if(game_matrix.row3[0]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,0+xoffs,0+yoffs);
		}
		if(game_matrix.row3[0]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,0+xoffs,0+yoffs);
		}

		if(game_matrix.row3[1]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,46+xoffs,0+yoffs);
		}
		if(game_matrix.row3[1]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,46+xoffs,0+yoffs);
		}
		if(game_matrix.row3[2]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,92+xoffs,0+yoffs);
		}
		if(game_matrix.row3[2]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,92+xoffs,0+yoffs);
		}


		//Középső sor:

		if(game_matrix.row2[0]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,0+xoffs,23+yoffs);
		}
		if(game_matrix.row2[0]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,0+xoffs,23+yoffs);
		}

		if(game_matrix.row2[1]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,46+xoffs,23+yoffs);
		}
		if(game_matrix.row2[1]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,46+xoffs,23+yoffs);
		}
		if(game_matrix.row2[2]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,92+xoffs,23+yoffs);
		}
		if(game_matrix.row2[2]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,92+xoffs,23+yoffs);
		}

		//Felső sor:
		if(game_matrix.row1[0]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,0+xoffs,46+yoffs);
		}
		if(game_matrix.row1[0]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,0+xoffs,46+yoffs);
		}

		if(game_matrix.row1[1]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,46+xoffs,46+yoffs);
		}
		if(game_matrix.row1[1]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,46+xoffs,46+yoffs);
		}
		if(game_matrix.row1[2]==1)
		{
			Draw_Player1_Symbol(lcd_buffer,size,92+xoffs,46+yoffs);
		}
		if(game_matrix.row1[2]==2)
		{
			Draw_Player2_Symbol(lcd_buffer,size,92+xoffs,46+yoffs);
		}

	}
}

