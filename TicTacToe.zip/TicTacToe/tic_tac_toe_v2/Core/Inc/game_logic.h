/*
 * game_logic.h
 *
 *  Created on: 2021. máj. 10.
 *      Author: Zsombi
 */

#ifndef INC_GAME_LOGIC_H_
#define INC_GAME_LOGIC_H_

#include <game_matrix.h>
#include <stdio.h>
typedef struct Game_Status{
	Game_Matrix game_matrix;
	uint8_t current_player;//uint8-ak!!
	uint8_t step;//hány lépés van, ez azért fontos, mert simán lehet, hogy döntetlen, tehát step=9 és Game_Over!=1->döntetlen
	uint8_t isGameOver;//Játék vége-e van-e: 0 nem 1 igen
}Game_Status;
//Kör végén játékos váltás
void Player_Change(int* currentplayer);
void inttoPos(uint8_t pressedkey,Cell_Pos* cell_pos);
//Játék inicializálása kezdés előtt::
//DrawMap
//GameMatrix létrehozása és alaphelyzetbe állítása
//element számláló alaphelyzetbe állítása
//kezdő játékos
void Game_Init(Game_Status* game_status);

//Game_Status Init:

void Game_Status_Init(Game_Status* game_status);

//Egy lépése a játéknak:
void Game_Iteration(Game_Status* game_status,int pressedkey);

//Ha az adott szám asci kódolásban 0 és 8 között van akkor 1-sel tér vissza
uint8_t iskeyValid(uint8_t key);


#endif /* INC_GAME_LOGIC_H_ */
