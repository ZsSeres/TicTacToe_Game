/*
 * game_logic.h
 *
 *  Created on: May 10, 2021
 *      Author: Zsombi
 *      Magát a logikát megvalósító függvények
 */

#ifndef INC_GAME_MATRIX_H_
#define INC_GAME_MATRIX_H_


//Poziciókat tartalmazó mátrix:
//3x3
//MÁTRIX POZICIÓJÁNAK SZÁMOZÁSA:
//	0 1 2
//	3 4 5
//	6 7 8
//
////////////////////////////////////


typedef struct Game_Matrix{
	int row1[3];
	int row2[3];
	int row3[3];
}Game_Matrix;

typedef struct Cell_Pos{
	int row;
	int column;
}Cell_Pos;

//Hozzátartozó fv-k:

void Clear_Matrix(Game_Matrix* matrix);
int Cell_isFree(Cell_Pos* cell_pos,Game_Matrix* matrix);
void Set_Cell(Cell_Pos* cell_pos,int current_player,Game_Matrix* matrix);

int isanyrowfull(int current_player,Game_Matrix* matrix);
int isanycolumnrowfull(int current_player,Game_Matrix* matrix);
int isanycrossfull(int current_player,Game_Matrix* matrix);
int isGame_Over(int currentplayer,Game_Matrix* matrix);

#endif /* INC_GAME_MATRIX_H_ */
